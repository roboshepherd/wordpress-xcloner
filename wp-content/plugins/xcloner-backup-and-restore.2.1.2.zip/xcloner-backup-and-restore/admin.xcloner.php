<?php

// no direct access
if(!defined( '_VALID_MOS' ) && !defined('_JEXEC'))

   die( 'Restricted access' );

print "<iframe src='components/com_xcloner/index.php' width='100%' height='900' frameborder=0 marginWidth=0 frameSpacing=0 marginHeight=110 ></iframe>";

?>
